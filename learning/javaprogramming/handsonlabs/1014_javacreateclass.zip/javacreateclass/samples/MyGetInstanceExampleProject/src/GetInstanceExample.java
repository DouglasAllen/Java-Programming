/*
 * GetInstanceExample.java
 *
 * Created on January 27, 2007, 4:18 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

/**
 *
 * @author sang
 */
public class GetInstanceExample {
    
    /** Creates a new instance of GetInstanceExample */
    public GetInstanceExample() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
