
package myfinalmethodexample;

public class Teacher extends Person{
    
    /** Creates a new instance of Teacher */
    public Teacher() {
    }
    
    // Try to override this method
    public void myMethod(){
    }
    
}
