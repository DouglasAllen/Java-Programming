
package myfinalmethodexample;

public class Person {
    
    /** Creates a new instance of Person */
    public Person() {
    }
    
    // myMethod() is a final method
    public final void myMethod(){
    }
}
