/*
 * Student.java
 *
 * Created on January 30, 2007, 1:18 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package mytypemismatchexampleproject;

/**
 *
 * @author sang
 */
public class Student extends Person {
    
    /** Creates a new instance of Student */
    public Student() {
    }
    
}
