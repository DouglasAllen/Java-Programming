/*
 * Teacher.java
 *
 * Created on February 2, 2007, 4:51 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package myfinalclassexample2;

/**
 *
 * @author sang
 */
public class Teacher extends String{
    
    /** Creates a new instance of Teacher */
    public Teacher() {
    }
    
}
