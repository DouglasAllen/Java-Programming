public @interface Mutator {
    String value();
}

