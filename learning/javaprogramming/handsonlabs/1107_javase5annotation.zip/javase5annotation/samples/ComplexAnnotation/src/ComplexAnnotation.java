
@Reviewer(@Name(first = "James", last = "Gosling"))
public class ComplexAnnotation {
    
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}