#! /bin/bash
# 
# File:   newshell.bash
# Author: gs145266
#
# Created on August 25, 2006, 3:03 PM
#

ls -l