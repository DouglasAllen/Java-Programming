package primenumbers.test;


class TestClass {
}

class TestClass2 {
    
    
}