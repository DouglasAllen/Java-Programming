package contact;

import java.util.ArrayList;

public class EMailAddress {
    
    private String address;

    public EMailAddress() {
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String val) {
        this.address = val;
    }


}
