package contact;

import java.util.ArrayList;
import java.util.Date;
import java.util.*;

public class PersonalIdentity {
    private String firstName;
    private String lastName;

    public PersonalIdentity() {
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String val) {
        this.firstName = val;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String val) {
        this.lastName = val;
    }

}
