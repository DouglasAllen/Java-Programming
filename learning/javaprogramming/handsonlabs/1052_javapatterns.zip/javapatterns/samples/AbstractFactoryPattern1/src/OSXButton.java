class OSXButton extends Button {
    public void paint() {
       System.out.println("I'm a OSXButton  : " + getCaption());
    }
}
