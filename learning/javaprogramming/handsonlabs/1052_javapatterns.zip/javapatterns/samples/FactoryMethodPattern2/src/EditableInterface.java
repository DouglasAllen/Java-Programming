interface EditableInterface {
    public ItemEditorInterface getEditor();
}
