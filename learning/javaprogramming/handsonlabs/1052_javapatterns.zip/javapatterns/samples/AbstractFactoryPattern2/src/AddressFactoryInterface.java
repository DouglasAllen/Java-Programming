interface AddressFactoryInterface {
    public AddressAbstractClass createAddress();
    public PhoneNumberAbstractClass createPhoneNumber();
}