interface ContactViewInterface{
    public void refreshContactView(String firstName,
        String lastName, String title, String organization);
}