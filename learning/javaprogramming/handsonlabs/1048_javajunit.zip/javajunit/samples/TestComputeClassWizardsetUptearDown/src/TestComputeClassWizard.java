/*
 * TestComputeClassWizard.java
 *
 * Created on March 2, 2007, 6:51 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

/**
 *
 * @author sang
 */
public class TestComputeClassWizard {
    
    /** Creates a new instance of TestComputeClassWizard */
    public TestComputeClassWizard() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
