package testpackage;

public class EmpAttributes {
    
    public static final int MINSALARY = 50000;
    public static final int MAXSALARY = 70000;
    public static final int MAXVACATION = 15;
    public static final int MAXANNUALRAISEPERCENTAGE = 10;
    
}