
package mypersoninterfaceproject;

public interface PersonInterface {
    
   // Compute person's total wealth
   int computeTotalWealth();
   
   // Get person's name
   String getName();
    
}
