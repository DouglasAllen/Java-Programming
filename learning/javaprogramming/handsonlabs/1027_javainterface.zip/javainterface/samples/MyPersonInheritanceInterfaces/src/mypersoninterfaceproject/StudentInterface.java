
package mypersoninterfaceproject;

// StudentInterface interface extends PersonInteface interface
public interface StudentInterface extends PersonInterface{
    
    // Find the school the student attends
    String findSchool();
    
}
