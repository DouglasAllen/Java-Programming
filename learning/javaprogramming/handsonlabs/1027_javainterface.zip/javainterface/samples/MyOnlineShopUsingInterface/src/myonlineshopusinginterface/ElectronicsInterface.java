
package myonlineshopusinginterface;

public interface ElectronicsInterface extends ProductInterface {
    
   public String getManufacturer();
    
}
