/*
 * NewInterface.java
 *
 * Created on February 12, 2007, 10:08 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package javaapplication116;

/**
 *
 * @author sang
 */
public interface NewInterface extends Object{
    

    
}
